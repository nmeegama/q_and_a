<?php
/**
 * @file
 * the tpl file to return the list of questions
 *
 */
?>
<div class="container-fluid">
  <div class="row question-list-container alert-warning" style="padding: 10px 5px;">
    <?php print $list; ?>
  </div>
</div>